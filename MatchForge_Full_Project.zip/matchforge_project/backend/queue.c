#include "queue.h"

void initQueue(PlayerQueue *q) {
    q->front = 0;
    q->rear = -1;
    q->count = 0;
}

int isEmpty(const PlayerQueue *q) {
    return q->count == 0;
}

int isFull(const PlayerQueue *q) {
    return q->count == MAX_QUEUE;
}

int enqueue(PlayerQueue *q, PlayerRequest req) {
    if (isFull(q)) return 0;
    q->rear = (q->rear + 1) % MAX_QUEUE;
    q->items[q->rear] = req;
    q->count++;
    return 1;
}

int dequeue(PlayerQueue *q, PlayerRequest *out) {
    if (isEmpty(q)) return 0;
    if (out) *out = q->items[q->front];
    q->front = (q->front + 1) % MAX_QUEUE;
    q->count--;
    return 1;
}

int peek(const PlayerQueue *q, PlayerRequest *out) {
    if (isEmpty(q)) return 0;
    if (out) *out = q->items[q->front];
    return 1;
}
