#include <string.h>
#include <stdio.h>
#include "matchmaking.h"

int getLoadPercent(const GameServer *s) {
    if (s->maxCapacity <= 0) return 100;
    return (s->currentPlayers * 100) / s->maxCapacity;
}

int checkServerEligibility(const GameServer *s, const PlayerRequest *req) {
    if (strcmp(s->region, req->region) != 0) return 0;
    if (strstr(s->supportedModes, req->mode) == NULL) return 0;
    if ((s->maxCapacity - s->currentPlayers) < req->partySize) return 0;
    return 1;
}

void updateServerLoad(GameServer *s, int partySize) {
    s->currentPlayers += partySize;
    if (s->currentPlayers > s->maxCapacity) {
        s->currentPlayers = s->maxCapacity;
    }
}

static void rebuildGlobalHeap(MinHeap *heap, GameServer servers[], int serverCount) {
    initHeap(heap);
    for (int i = 0; i < serverCount; i++) {
        HeapNode node = { servers[i].id, getLoadPercent(&servers[i]) };
        insertHeap(heap, node);
    }
}

int processNextPlayer(PlayerQueue *q, GameServer servers[], int serverCount, MinHeap *globalHeap) {
    PlayerRequest frontPlayer;
    if (!peek(q, &frontPlayer)) {
        printf("[INFO] Queue is empty.\n");
        return 0;
    }

    MinHeap eligibleHeap;
    initHeap(&eligibleHeap);

    for (int i = 0; i < serverCount; i++) {
        if (checkServerEligibility(&servers[i], &frontPlayer)) {
            HeapNode node = { servers[i].id, getLoadPercent(&servers[i]) };
            insertHeap(&eligibleHeap, node);
        }
    }

    HeapNode bestServerNode;
    if (!extractMin(&eligibleHeap, &bestServerNode)) {
        printf("[WAIT] No suitable server for %s (%s, %s, Party %d). Kept at queue front.\n",
               frontPlayer.name, frontPlayer.region, frontPlayer.mode, frontPlayer.partySize);
        return 0;
    }

    dequeue(q, &frontPlayer);
    for (int i = 0; i < serverCount; i++) {
        if (servers[i].id == bestServerNode.serverId) {
            updateServerLoad(&servers[i], frontPlayer.partySize);
            printf("[MATCH] %s (Party %d) -> %s (New Load: %d%%)\n",
                   frontPlayer.name, frontPlayer.partySize, servers[i].name, getLoadPercent(&servers[i]));
            break;
        }
    }

    rebuildGlobalHeap(globalHeap, servers, serverCount);
    return 1;
}
