#include "minheap.h"

static void swapNodes(HeapNode *a, HeapNode *b) {
    HeapNode tmp = *a;
    *a = *b;
    *b = tmp;
}

void initHeap(MinHeap *h) {
    h->size = 0;
}

void heapifyUp(MinHeap *h, int index) {
    while (index > 0) {
        int parent = (index - 1) / 2;
        if (h->nodes[index].loadPercent < h->nodes[parent].loadPercent) {
            swapNodes(&h->nodes[index], &h->nodes[parent]);
            index = parent;
        } else {
            break;
        }
    }
}

void heapifyDown(MinHeap *h, int index) {
    while (1) {
        int left = 2 * index + 1;
        int right = 2 * index + 2;
        int smallest = index;

        if (left < h->size && h->nodes[left].loadPercent < h->nodes[smallest].loadPercent) {
            smallest = left;
        }
        if (right < h->size && h->nodes[right].loadPercent < h->nodes[smallest].loadPercent) {
            smallest = right;
        }
        if (smallest != index) {
            swapNodes(&h->nodes[index], &h->nodes[smallest]);
            index = smallest;
        } else {
            break;
        }
    }
}

void insertHeap(MinHeap *h, HeapNode node) {
    if (h->size >= MAX_SERVERS) return;
    h->nodes[h->size] = node;
    heapifyUp(h, h->size);
    h->size++;
}

int getMin(const MinHeap *h, HeapNode *out) {
    if (h->size == 0) return 0;
    if (out) *out = h->nodes[0];
    return 1;
}

int extractMin(MinHeap *h, HeapNode *out) {
    if (h->size == 0) return 0;
    if (out) *out = h->nodes[0];
    h->size--;
    if (h->size > 0) {
        h->nodes[0] = h->nodes[h->size];
        heapifyDown(h, 0);
    }
    return 1;
}
