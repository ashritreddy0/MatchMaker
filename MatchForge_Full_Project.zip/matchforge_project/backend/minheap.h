#ifndef MINHEAP_H
#define MINHEAP_H

#define MAX_SERVERS 20

typedef struct {
    int serverId;
    int loadPercent;
} HeapNode;

typedef struct {
    HeapNode nodes[MAX_SERVERS];
    int size;
} MinHeap;

void initHeap(MinHeap *h);
void insertHeap(MinHeap *h, HeapNode node);
int getMin(const MinHeap *h, HeapNode *out);
int extractMin(MinHeap *h, HeapNode *out);
void heapifyUp(MinHeap *h, int index);
void heapifyDown(MinHeap *h, int index);

#endif
