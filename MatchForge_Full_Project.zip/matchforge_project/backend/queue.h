#ifndef QUEUE_H
#define QUEUE_H

#define MAX_QUEUE 50

typedef struct {
    int id;
    char name[64];
    char region[32];
    char mode[32];
    int partySize;
} PlayerRequest;

typedef struct {
    PlayerRequest items[MAX_QUEUE];
    int front;
    int rear;
    int count;
} PlayerQueue;

void initQueue(PlayerQueue *q);
int isEmpty(const PlayerQueue *q);
int isFull(const PlayerQueue *q);
int enqueue(PlayerQueue *q, PlayerRequest req);
int dequeue(PlayerQueue *q, PlayerRequest *out);
int peek(const PlayerQueue *q, PlayerRequest *out);

#endif
