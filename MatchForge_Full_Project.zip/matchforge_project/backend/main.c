#include <stdio.h>
#include <string.h>
#include "queue.h"
#include "minheap.h"
#include "matchmaking.h"

int main(void) {
    PlayerQueue queue;
    MinHeap globalHeap;
    initQueue(&queue);
    initHeap(&globalHeap);

    GameServer servers[] = {
        {1, "Mumbai Gateway",    "India",     "Competitive,Casual,Deathmatch", 40, 100},
        {2, "Delhi Gateway",     "India",     "Competitive,Casual",            78, 100},
        {3, "Bengaluru Gateway", "India",     "Casual,Deathmatch",             20, 100},
        {4, "Singapore Gateway", "Singapore", "Competitive,Casual,Deathmatch", 30, 100},
        {5, "Frankfurt Gateway", "Europe",    "Competitive,Casual",            50, 100}
    };
    int serverCount = 5;

    for (int i = 0; i < serverCount; i++) {
        HeapNode node = { servers[i].id, getLoadPercent(&servers[i]) };
        insertHeap(&globalHeap, node);
    }

    printf("=== MatchForge C Engine Simulation ===\n");
    PlayerRequest r1 = {101, "Ashrit", "India", "Competitive", 4};
    PlayerRequest r2 = {102, "Vineet", "Europe", "Deathmatch", 2};
    PlayerRequest r3 = {103, "Hari",   "India", "Casual", 3};

    enqueue(&queue, r1);
    enqueue(&queue, r2);
    enqueue(&queue, r3);

    processNextPlayer(&queue, servers, serverCount, &globalHeap);
    processNextPlayer(&queue, servers, serverCount, &globalHeap);
    processNextPlayer(&queue, servers, serverCount, &globalHeap);

    return 0;
}
