#ifndef MATCHMAKING_H
#define MATCHMAKING_H

#include "queue.h"
#include "minheap.h"

typedef struct {
    int id;
    char name[64];
    char region[32];
    char supportedModes[128];
    int currentPlayers;
    int maxCapacity;
} GameServer;

int getLoadPercent(const GameServer *s);
int checkServerEligibility(const GameServer *s, const PlayerRequest *req);
void updateServerLoad(GameServer *s, int partySize);
int processNextPlayer(PlayerQueue *q, GameServer servers[], int serverCount, MinHeap *globalHeap);

#endif
