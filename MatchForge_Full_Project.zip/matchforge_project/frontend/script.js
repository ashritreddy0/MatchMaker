// MatchForge Frontend Simulation (Mirrors C Queue + Min-Heap Modules)

const INITIAL_SERVERS = () => [
  { id: 1, name: "Mumbai Gateway",    region: "India",     modes: ["Competitive", "Casual", "Deathmatch"], current: 40, capacity: 100 },
  { id: 2, name: "Delhi Gateway",     region: "India",     modes: ["Competitive", "Casual"],               current: 78, capacity: 100 },
  { id: 3, name: "Bengaluru Gateway", region: "India",     modes: ["Casual", "Deathmatch"],                current: 20, capacity: 100 },
  { id: 4, name: "Singapore Gateway", region: "Singapore", modes: ["Competitive", "Casual", "Deathmatch"], current: 30, capacity: 100 },
  { id: 5, name: "Frankfurt Gateway", region: "Europe",    modes: ["Competitive", "Casual"],               current: 50, capacity: 100 }
];

// FIFO Queue implementation (mirrors queue.c)
class FIFOQueue {
  constructor() { this.items = []; }
  enqueue(req) { this.items.push(req); }
  dequeue() { return this.items.shift(); }
  peek() { return this.items[0] || null; }
  isEmpty() { return this.items.length === 0; }
}

// Binary Min-Heap implementation (mirrors minheap.c)
class MinHeap {
  constructor() { this.nodes = []; }
  insert(node) {
    this.nodes.push(node);
    this.heapifyUp(this.nodes.length - 1);
  }
  extractMin() {
    if (this.nodes.length === 0) return null;
    const min = this.nodes[0];
    const end = this.nodes.pop();
    if (this.nodes.length > 0) {
      this.nodes[0] = end;
      this.heapifyDown(0);
    }
    return min;
  }
  heapifyUp(idx) {
    while (idx > 0) {
      const parent = Math.floor((idx - 1) / 2);
      if (this.nodes[idx].load < this.nodes[parent].load) {
        [this.nodes[idx], this.nodes[parent]] = [this.nodes[parent], this.nodes[idx]];
        idx = parent;
      } else break;
    }
  }
  heapifyDown(idx) {
    const n = this.nodes.length;
    while (true) {
      let smallest = idx;
      const left = 2 * idx + 1;
      const right = 2 * idx + 2;
      if (left < n && this.nodes[left].load < this.nodes[smallest].load) smallest = left;
      if (right < n && this.nodes[right].load < this.nodes[smallest].load) smallest = right;
      if (smallest !== idx) {
        [this.nodes[idx], this.nodes[smallest]] = [this.nodes[smallest], this.nodes[idx]];
        idx = smallest;
      } else break;
    }
  }
}

let queue = new FIFOQueue();
let servers = INITIAL_SERVERS();
let matchesCount = 0;
let nextReqId = 101;
let lastPickedServerId = null;

function loadPercent(s) {
  return Math.round((s.current / s.capacity) * 100);
}

function buildGlobalMinHeap() {
  const heap = new MinHeap();
  servers.forEach(s => heap.insert({ id: s.id, name: s.name, load: loadPercent(s) }));
  return heap;
}

function logEvent(msg, type = "") {
  const ul = document.getElementById("eventLog");
  const li = document.createElement("li");
  if (type) li.className = type;
  li.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`;
  ul.prepend(li);
}

function checkEligibility(server, req) {
  const regionOk = server.region === req.region;
  const modeOk = server.modes.includes(req.mode);
  const capOk = (server.capacity - server.current) >= req.partySize;
  return { eligible: regionOk && modeOk && capOk, regionOk, modeOk, capOk };
}

function processNextPlayer() {
  const front = queue.peek();
  if (!front) {
    logEvent("Queue is empty — nothing to process.", "warn");
    return false;
  }

  const eligibleHeap = new MinHeap();
  const checks = servers.map(s => {
    const res = checkEligibility(s, front);
    if (res.eligible) {
      eligibleHeap.insert({ id: s.id, name: s.name, load: loadPercent(s) });
    }
    return { server: s, ...res };
  });

  const best = eligibleHeap.extractMin();
  renderEligibility(front, checks, best ? best.id : null);

  if (!best) {
    lastPickedServerId = null;
    logEvent(`WAIT: No eligible server for ${front.name} (${front.region}, ${front.mode}, Party ${front.partySize}). Kept at queue front.`, "warn");
    renderAll();
    return false;
  }

  queue.dequeue();
  const chosen = servers.find(s => s.id === best.id);
  chosen.current += front.partySize;
  matchesCount++;
  lastPickedServerId = chosen.id;

  logEvent(`MATCH: ${front.name} (Party ${front.partySize}) -> ${chosen.name} (Load updated to ${loadPercent(chosen)}%).`, "ok");
  renderAll();
  return true;
}

function renderEligibility(req, checks, pickedId) {
  const box = document.getElementById("eligibilityBox");
  box.innerHTML = `<div>Inspecting Front Player: <strong>${req.name}</strong> (${req.region} &bull; ${req.mode} &bull; Party ${req.partySize})</div>` +
    checks.map(c => {
      const isPick = c.server.id === pickedId;
      const status = isPick
        ? `<span class="pass">MIN-HEAP PICK (${loadPercent(c.server)}%)</span>`
        : c.eligible
          ? `<span class="pass">ELIGIBLE (${loadPercent(c.server)}%)</span>`
          : `<span class="fail">REJECTED (${!c.regionOk ? "Region" : !c.modeOk ? "Mode" : "Capacity"})</span>`;
      return `<div class="elig-row"><span>${c.server.name}</span>${status}</div>`;
    }).join("");
}

function renderAll() {
  // Stats
  document.getElementById("statWaiting").textContent = queue.items.length;
  document.getElementById("statServers").textContent = servers.length;
  const avg = Math.round(servers.reduce((acc, s) => acc + loadPercent(s), 0) / servers.length);
  document.getElementById("statAvgLoad").textContent = `${avg}%`;
  document.getElementById("statMatches").textContent = matchesCount;

  // Queue
  const qEl = document.getElementById("queueContainer");
  qEl.innerHTML = queue.items.length === 0
    ? `<p class="muted">Waiting queue is empty.</p>`
    : queue.items.map((p, i) => `
      <div class="queue-item ${i === 0 ? "front" : ""}">
        <div>
          <strong>${p.name}</strong> <span class="muted">(#${p.id})</span><br/>
          <small class="muted">${p.region} &bull; ${p.mode} &bull; Party of ${p.partySize}</small>
        </div>
        ${i === 0 ? `<span class="tag">FRONT</span>` : `<span class="muted">#${i + 1}</span>`}
      </div>
    `).join("");

  // Servers
  const sEl = document.getElementById("serversContainer");
  sEl.innerHTML = servers.map(s => {
    const pct = loadPercent(s);
    return `
      <div class="server-item ${s.id === lastPickedServerId ? "picked" : ""}">
        <div class="server-top">
          <span>${s.name} (${s.region})</span>
          <span>${pct}% (${s.current}/${s.capacity})</span>
        </div>
        <div class="server-meta">Modes: ${s.modes.join(", ")}</div>
        <div class="bar-bg"><div class="bar-fill" style="width:${pct}%"></div></div>
      </div>
    `;
  }).join("");

  // Min-Heap
  const heap = buildGlobalMinHeap();
  const levels = [heap.nodes.slice(0, 1), heap.nodes.slice(1, 3), heap.nodes.slice(3, 7)];
  document.getElementById("heapTree").innerHTML = levels.filter(l => l.length).map((lvl, lIdx) => `
    <div class="heap-level">
      ${lvl.map((n, i) => `<div class="heap-node ${lIdx === 0 && i === 0 ? "root" : ""}"><strong>${n.load}%</strong><br/>${n.name.replace(" Gateway", "")}</div>`).join("")}
    </div>
  `).join("");

  document.getElementById("heapArray").innerHTML = heap.nodes.map((n, idx) =>
    `<span class="heap-cell">[${idx}] ${n.name.replace(" Gateway", "")}: ${n.load}%</span>`
  ).join("");
}

document.getElementById("joinForm").addEventListener("submit", e => {
  e.preventDefault();
  const req = {
    id: nextReqId++,
    name: document.getElementById("playerName").value.trim(),
    region: document.getElementById("playerRegion").value,
    mode: document.getElementById("playerMode").value,
    partySize: parseInt(document.getElementById("partySize").value, 10)
  };
  queue.enqueue(req);
  logEvent(`ENQUEUE: ${req.name} (${req.region}, ${req.mode}, Party ${req.partySize}) added to rear.`);
  document.getElementById("playerName").value = "";
  renderAll();
});

document.getElementById("btnProcessNext").addEventListener("click", processNextPlayer);
document.getElementById("btnProcessAll").addEventListener("click", () => {
  while (!queue.isEmpty()) {
    if (!processNextPlayer()) break;
  }
});

document.getElementById("btnLoadSamples").addEventListener("click", () => {
  [
    { id: nextReqId++, name: "Ashrit",  region: "India",     mode: "Competitive", partySize: 4 },
    { id: nextReqId++, name: "Vineet",  region: "Europe",    mode: "Deathmatch",  partySize: 2 },
    { id: nextReqId++, name: "Hari",    region: "India",     mode: "Casual",      partySize: 3 },
    { id: nextReqId++, name: "Vinayak", region: "Singapore", mode: "Competitive", partySize: 5 }
  ].forEach(r => queue.enqueue(r));
  logEvent("Loaded 4 sample player requests into FIFO queue.");
  renderAll();
});

document.getElementById("btnReset").addEventListener("click", () => {
  queue = new FIFOQueue();
  servers = INITIAL_SERVERS();
  matchesCount = 0;
  nextReqId = 101;
  lastPickedServerId = null;
  document.getElementById("eventLog").innerHTML = "";
  document.getElementById("eligibilityBox").innerHTML = `<p class="muted">Simulation reset. Enqueue players to begin.</p>`;
  logEvent("Simulation reset to initial state.");
  renderAll();
});

logEvent("MatchForge initialized with 5 regional servers.");
renderAll();
