# MatchForge — Multiplayer Game Server Matchmaking System

Data Structures Mini-Project using **FIFO Queue** and **Binary Min-Heap** (Core logic in **C**, Dashboard in **HTML5, CSS3 & JavaScript**).

## Folder Structure
```text
matchforge_project/
├── backend/
│   ├── queue.h / queue.c             # Circular FIFO Queue (enqueue, dequeue, peek, isEmpty)
│   ├── minheap.h / minheap.c         # Binary Min-Heap (insertHeap, getMin, extractMin, heapify)
│   ├── matchmaking.h / matchmaking.c # Eligibility checks (Region, Mode, Capacity) & load updates
│   └── main.c                        # Standalone C simulation runner
├── frontend/
│   ├── index.html                    # Dashboard UI
│   ├── style.css                     # Dark theme layout & load bars
│   └── script.js                     # Interactive Queue + Min-Heap visualization
└── README.md
```

## Quick Run
1. **Frontend Dashboard:** Open `frontend/index.html` directly in any browser (or enable **GitHub Pages** on `/frontend` or root).
2. **C Backend Compilation:**
   ```bash
   cd backend
   gcc main.c queue.c minheap.c matchmaking.c -o matchforge
   ./matchforge
   ```
